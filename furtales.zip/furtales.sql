CREATE DATABASE  IF NOT EXISTS `furtales` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `furtales`;
-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: furtales
-- ------------------------------------------------------
-- Server version	5.7.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `admin_id` varchar(10) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `admin_cn` varchar(45) DEFAULT NULL,
  `admin_email` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `admin_id_UNIQUE` (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES ('201','Gates','Bill',NULL,NULL),('202','Jobs','Steve',NULL,NULL);
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat`
--

DROP TABLE IF EXISTS `chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat` (
  `message_id` varchar(10) NOT NULL,
  `sp_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `message` longtext NOT NULL,
  `date` date DEFAULT NULL,
  `time` time(6) DEFAULT NULL,
  PRIMARY KEY (`message_id`),
  KEY `sp_id_idx` (`sp_id`),
  KEY `customer_id_idx` (`client_id`),
  KEY `client_id_idx` (`client_id`),
  KEY `user_id_idx` (`client_id`),
  CONSTRAINT `sp_id` FOREIGN KEY (`sp_id`) REFERENCES `service provider` (`staff_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `user_id` FOREIGN KEY (`client_id`) REFERENCES `client` (`client_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat`
--

LOCK TABLES `chat` WRITE;
/*!40000 ALTER TABLE `chat` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client` (
  `client_id` int(11) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `client_address` varchar(45) NOT NULL,
  `client_cn` varchar(45) NOT NULL,
  `client_email` varchar(45) NOT NULL,
  PRIMARY KEY (`client_id`),
  UNIQUE KEY `client_id_UNIQUE` (`client_id`),
  UNIQUE KEY `email_UNIQUE` (`client_email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES (3000,'mortel','bobbie','1000','0123456789','mortelbob@gmail.com'),(3001,'ugaldo','jovi','1001','0987654321','joviugaldo@yahoo.com'),(3002,'zareno','troy','1002','6985320147','troyzareno@yahoo.com'),(3003,'mones','angelica','1003','3412698750','angelicargmns@gmail.com'),(3004,'dupingay','jj','1004','8532691740','dupingayjj@yahoo.com'),(3005,'soriano','rosmella','1005','1253698704','rjsoriano@gmail.com');
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log`
--

DROP TABLE IF EXISTS `log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log` (
  `log_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `log_date` date NOT NULL,
  `log_time` time(6) NOT NULL,
  `transaction_id` varchar(45) NOT NULL,
  `client_id` int(11) NOT NULL,
  `sp_id` int(11) NOT NULL,
  PRIMARY KEY (`log_id`,`client_id`),
  UNIQUE KEY `address_id_UNIQUE` (`log_id`),
  UNIQUE KEY `client_id_UNIQUE` (`client_id`),
  UNIQUE KEY `log_date_UNIQUE` (`log_date`),
  UNIQUE KEY `log_time_UNIQUE` (`log_time`),
  KEY `transaction_id_idx` (`transaction_id`),
  KEY `customer_id_idx` (`client_id`),
  KEY `staff_id_idx` (`sp_id`),
  KEY `service_id_idx` (`service_id`),
  KEY `labor_id_idx` (`service_id`),
  KEY `date_idx` (`log_date`),
  CONSTRAINT `client_id` FOREIGN KEY (`client_id`) REFERENCES `client` (`client_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `date` FOREIGN KEY (`log_date`) REFERENCES `transaction` (`transaction_date`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `labor_id` FOREIGN KEY (`service_id`) REFERENCES `service` (`service_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `staff_id` FOREIGN KEY (`sp_id`) REFERENCES `service provider` (`staff_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `transaction_id` FOREIGN KEY (`transaction_id`) REFERENCES `transaction` (`transaction_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log`
--

LOCK TABLES `log` WRITE;
/*!40000 ALTER TABLE `log` DISABLE KEYS */;
/*!40000 ALTER TABLE `log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service`
--

DROP TABLE IF EXISTS `service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service` (
  `service_id` int(11) NOT NULL,
  `service_name` varchar(45) NOT NULL,
  `price` double NOT NULL,
  `service_description` mediumtext NOT NULL,
  PRIMARY KEY (`service_id`),
  UNIQUE KEY `service_id_UNIQUE` (`service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service`
--

LOCK TABLES `service` WRITE;
/*!40000 ALTER TABLE `service` DISABLE KEYS */;
INSERT INTO `service` VALUES (4000,'grooming package',450,'bath, shampoo, blowdry, ear cleaning, nail trim, sanitary trim, teeth brushing, haircut'),(4001,'ear cleaning',75,'cleaning of the ear'),(4002,'tear stain removal',100,'removal of tear stain caused by ......'),(4003,'pet massage',200,'massaging your pet for them to relax'),(4004,'peticure nail caps removal',100,'**'),(4005,'teeth brushing',75,'brushing of the teeth '),(4006,'dematting',450,'**'),(4007,'mouth wash',75,'**'),(4008,'eye wash',75,'**'),(4009,'nail trim and filing',100,'**');
/*!40000 ALTER TABLE `service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service provider`
--

DROP TABLE IF EXISTS `service provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service provider` (
  `staff_id` int(11) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `service_id` int(11) NOT NULL,
  `sp_email` varchar(45) DEFAULT NULL,
  `sp_cn` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`staff_id`),
  UNIQUE KEY `sp_id_UNIQUE` (`staff_id`),
  KEY `service_id_idx` (`service_id`),
  CONSTRAINT `service_id` FOREIGN KEY (`service_id`) REFERENCES `service` (`service_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service provider`
--

LOCK TABLES `service provider` WRITE;
/*!40000 ALTER TABLE `service provider` DISABLE KEYS */;
/*!40000 ALTER TABLE `service provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction` (
  `transaction_id` varchar(45) NOT NULL,
  `service_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `price` double NOT NULL,
  `payment_status` varchar(10) NOT NULL DEFAULT 'Not Paid',
  `transaction_date` date NOT NULL,
  `transaction_time` time(6) NOT NULL,
  PRIMARY KEY (`transaction_id`),
  UNIQUE KEY `transaction_id_UNIQUE` (`transaction_id`),
  UNIQUE KEY `transaction_date_UNIQUE` (`transaction_date`),
  UNIQUE KEY `transaction_time_UNIQUE` (`transaction_time`),
  KEY `price_idx` (`price`),
  KEY `service_id_idx` (`service_id`),
  KEY `service_id_idxx` (`service_id`),
  KEY `service_id_index` (`service_id`),
  KEY `customer_id_idx` (`client_id`),
  CONSTRAINT `customer_id` FOREIGN KEY (`client_id`) REFERENCES `client` (`client_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction`
--

LOCK TABLES `transaction` WRITE;
/*!40000 ALTER TABLE `transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `transaction` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-04-28 22:37:48
